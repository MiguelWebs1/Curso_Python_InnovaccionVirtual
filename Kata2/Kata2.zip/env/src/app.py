{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    " from datetime import *\n",
    "  from dateutil.relativedelta import *\n",
    "  now = datetime.now()\n",
    "  print(now)\n",
    "\n",
    "  now = now + relativedelta(months=1, weeks=1, hour=10)\n",
    "\n",
    "  print(now)"
   ]
  }
 ],
 "metadata": {
  "language_info": {
   "name": "python"
  },
  "orig_nbformat": 4
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
